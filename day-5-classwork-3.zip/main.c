/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    
    int arr[] = {5, 2, 7, 4, 9, 1};

   
    int max_val = arr[0];
    int min_val = arr[0];

    
    for (int i = 1; i < 6; i++) {
        if (arr[i] > max_val) {
            max_val = arr[i];
        }
        if (arr[i] < min_val) {
            min_val = arr[i];
        }
    }

   
    printf("The maximum value in the array is: %d\n", max_val);
    printf("The minimum value in the array is: %d\n", min_val);

    return 0;
}
