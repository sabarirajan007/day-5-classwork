#include <stdio.h>

int main() {
    int mat1[10][10], mat2[10][10], row1, col1, row2, col2, i, j, equal = 1;

    
    printf("Enter the number of rows and columns of the first matrix: ");
    scanf("%d %d", &row1, &col1);
    printf("Enter the elements of the first matrix:\n");
    for (i = 0; i < row1; i++) {
        for (j = 0; j < col1; j++) {
            scanf("%d", &mat1[i][j]);
        }
    }

  
    printf("Enter the number of rows and columns of the second matrix: ");
    scanf("%d %d", &row2, &col2);
    printf("Enter the elements of the second matrix:\n");
    for (i = 0; i < row2; i++) {
        for (j = 0; j < col2; j++) {
            scanf("%d", &mat2[i][j]);
        }
    }


    if (row1 == row2 && col1 == col2) {
        for (i = 0; i < row1; i++) {
            for (j = 0; j < col1; j++) {
                if (mat1[i][j] != mat2[i][j]) {
                    equal = 0;
                    break;
                }
            }
            if (!equal) {
                break;
            }
        }
    } else {
        equal = 0;
    }

  
    if (equal) {
        printf("\nThe two matrices are equal.\n");
    } else {
        printf("\nThe two matrices are not equal.\n");
    }

    return 0;
}
