/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    // Define a matrix array
    int matrix[3][3] = {{1, 2, 3},
                        {4, 5, 6},
                        {7, 8, 9}};

    // Initialize variables to store the sum and count of matrix elements
    int sum = 0;
    int count = 0;

    // Loop through the rows and columns of the matrix
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            // Add the current matrix element to the sum and update the count
            sum += matrix[i][j];
            count++;
        }
    }

    // Calculate the average of matrix elements
    float average = (float) sum / count;

    // Display the sum and average of matrix elements
    printf("The sum of matrix elements is: %d\n", sum);
    printf("The average of matrix elements is: %f\n", average);

    return 0;
}
