/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int n, i;
    float sum = 0.0;

   
    printf("Enter the value of n: ");
    scanf("%d", &n);

   
    printf("Harmonic Series: 1 ");
    for (i = 2; i <= n; i++) {
        printf("+ 1/%d ", i);
        sum += 1.0/i;
    }

   
    printf("\nSum of the series up to %d terms: %f", n, sum);

    return 0;
}
